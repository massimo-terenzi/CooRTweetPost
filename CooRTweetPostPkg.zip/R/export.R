#' Export post-processed summaries to CSV
#'
#' @param coordinated_groups Output from detect_groups()
#' @param network_graph Output from generate_coordinated_network()
#' @param output_dir Directory to save CSV files
#' @export
export_for_web <- function(coordinated_groups, network_graph, output_dir = "postprocessor_output") {
  stopifnot(igraph::is_igraph(network_graph))
  dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

  vertex <- create_vertex_summary_table(coordinated_groups, network_graph)
  community <- create_community_summary_table(coordinated_groups, network_graph)
  objects <- create_object_summary_table(coordinated_groups, network_graph)

  data.table::fwrite(vertex, file.path(output_dir, "vertex_summary.csv"))
  data.table::fwrite(community, file.path(output_dir, "community_summary.csv"))
  data.table::fwrite(objects$object_summary, file.path(output_dir, "coordinated_objects.csv"))
  data.table::fwrite(objects$object_community_long, file.path(output_dir, "coordinated_objects_by_community.csv"))

  message("✅ Outputs saved in: ", normalizePath(output_dir))
}
